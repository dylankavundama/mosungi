document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('.nav-item');
    const contentArea = document.getElementById('content');
    const burgerMenu = document.querySelector('.burger-menu');
    const nav = document.querySelector('nav');

    // Mettre en place un contenu de base pour chaque page
    const pageContent = {
        'accueil': `
            <section class="hero">
                <h1>Construire un Avenir Meilleur Ensemble</h1>
                <p>La Fondation [Nom de la Fondation] s'engage à transformer des vies et à créer un impact durable dans nos communautés.</p>
                <a href="#mission" class="btn-primary nav-item">Découvrir notre mission</a>
            </section>

            <section id="a-propos">
                <h2>Qui sommes-nous ?</h2>
                <p>La Fondation [Nom de la Fondation] est dédiée à l'amélioration de la société à travers des initiatives ciblées dans l'éducation, la santé et le développement durable. Depuis notre création en [Année], nous avons soutenu des centaines de projets et impacté des milliers de vies. Notre force réside dans notre engagement indéfectible et notre capacité à mobiliser des ressources pour les causes qui comptent le plus.</p>
                <div class="info-section">
                    <div class="info-card">
                        <h3>Notre Impact</h3>
                        <p>Découvrez comment nos actions ont un effet concret sur le terrain et la vie des bénéficiaires.</p>
                    </div>
                    <div class="info-card">
                        <h3>Nos Projets</h3>
                        <p>Explorez nos initiatives actuelles et passées, et les résultats que nous avons obtenus.</p>
                    </div>
                    <div class="info-card">
                        <h3>Comment Aider ?</h3>
                        <p>Apprenez comment votre soutien, quel qu'il soit, peut faire une réelle différence.</p>
                    </div>
                </div>
            </section>

            <section class="cta-section">
                <h2>Rejoignez notre mission !</h2>
                <p>Votre soutien nous permet de continuer notre travail essentiel. Chaque don, chaque partenariat compte.</p>
                <a href="#contact" class="btn-secondary nav-item">Faire un don ou Devenir partenaire</a>
            </section>
        `,
        'vision': `
            <section id="vision">
                <h2>Notre Vision</h2>
                <p>Nous aspirons à un monde où l'égalité des chances et la durabilité sont au cœur de chaque communauté. Notre vision est de créer un impact durable et positif sur les générations futures.</p>
                <p>Nous imaginons une société où chaque individu a accès aux ressources nécessaires pour s'épanouir, où l'éducation est un droit universel, la santé une priorité et l'environnement un patrimoine protégé pour tous. C'est vers cet idéal que nous orientons toutes nos actions et nos partenariats.</p>
            </section>
        `,
        'mission': `
            <section id="mission">
                <h2>Notre Mission</h2>
                <p>Notre mission est de financer et de soutenir des projets qui transforment la vie des individus et des communautés. Nous nous concentrons sur l'éducation, la santé et l'environnement, car nous croyons en leur pouvoir de changer le monde.</p>
                <p>Nous identifions les besoins critiques, collaborons avec des organisations locales et internationales, et investissons dans des solutions innovantes. Notre objectif est de maximiser l'efficacité de nos interventions et d'assurer une amélioration tangible et mesurable dans la vie des personnes que nous servons.</p>
            </section>
        `,
        'valeurs': `
            <section id="valeurs">
                <h2>Nos Valeurs</h2>
                <ul>
                    <li><strong>Transparence:</strong> Nous agissons avec intégrité, honnêteté et clarté dans toutes nos opérations et nos rapports financiers.</li>
                    <li><strong>Empathie:</strong> Nous nous mettons à la place des communautés que nous servons, en écoutant attentivement leurs besoins et en y répondant avec compassion.</li>
                    <li><strong>Innovation:</strong> Nous cherchons constamment des approches nouvelles et créatives pour résoudre les défis complexes et maximiser notre impact.</li>
                    <li><strong>Collaboration:</strong> Nous croyons en la force du partenariat, travaillant main dans la main avec d'autres organisations, donateurs et bénéficiaires.</li>
                    <li><strong>Responsabilité:</strong> Nous nous engageons à une gestion rigoureuse de nos ressources et à la redevabilité envers nos parties prenantes.</li>
                </ul>
            </section>
        `,
        'charte': `
            <section id="charte">
                <h2>Notre Charte Éthique</h2>
                <p>La charte de la fondation établit nos principes de conduite, nos engagements éthiques et nos directives de fonctionnement pour garantir une gouvernance responsable et efficace. Elle guide toutes nos décisions et actions, assurant que nous restons fidèles à notre mission et à nos valeurs.</p>
                <p>Elle couvre des aspects tels que la gestion des fonds, la non-discrimination, la protection des données, et les relations avec nos partenaires et le public. Tous les membres de la fondation s'engagent à respecter cette charte.</p>
            </section>
        `,
        'gouvernance': `
            <section id="gouvernance">
                <h2>Gouvernance de la Fondation</h2>
                <p>Notre structure de gouvernance est composée d'un conseil d'administration et d'un comité exécutif, garantissant une gestion saine et une allocation stratégique des ressources. Chaque organe joue un rôle essentiel pour assurer la transparence, l'efficacité et l'alignement avec notre mission.</p>
                <h3>Conseil d'Administration</h3>
                <p>Le Conseil d'Administration supervise la stratégie générale, la gestion financière et la conformité légale de la fondation. Il est composé de membres experts issus de divers domaines.</p>
                <h3>Comité Exécutif</h3>
                <p>Le Comité Exécutif est responsable de la mise en œuvre des décisions du Conseil et de la gestion quotidienne des opérations de la fondation, sous la direction du Directeur Général.</p>
            </section>
        `,
        'contact': `
            <section id="contact">
                <h2>Contactez-nous</h2>
                <p>Vous avez une question, une proposition de partenariat ou souhaitez faire un don ? N'hésitez pas à nous contacter. Notre équipe est à votre disposition pour vous répondre dans les plus brefs délais.</p>
                <form>
                    <label for="nom">Nom Complet:</label><br>
                    <input type="text" id="nom" name="nom" required><br><br>
                    <label for="email">Adresse Email:</label><br>
                    <input type="email" id="email" name="email" required><br><br>
                    <label for="sujet">Sujet:</label><br>
                    <input type="text" id="sujet" name="sujet"><br><br>
                    <label for="message">Votre Message:</label><br>
                    <textarea id="message" name="message" rows="6" required></textarea><br><br>
                    <button type="submit" class="btn-primary">Envoyer le message</button>
                </form>
                <p style="margin-top: 2rem;"><strong>Email:</strong> info@votrefondation.com</p>
                <p><strong>Téléphone:</strong> +123 456 7890</p>
                <p><strong>Adresse:</strong> 123 Rue de la Fondation, Ville, Code Postal</p>
            </section>
        `
    };

    // Fonction pour charger le contenu de la page
    const loadPage = (pageName) => {
        contentArea.innerHTML = pageContent[pageName] || pageContent['accueil'];
        // Faire défiler vers le haut de la page après le chargement du contenu
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    // Gérer la navigation
    navLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const page = link.getAttribute('href').substring(1); // Enlever le #
            loadPage(page);
            // Fermer le menu burger sur mobile après un clic
            if (nav.classList.contains('active')) {
                nav.classList.remove('active');
            }
        });
    });

    // Gérer le menu burger
    burgerMenu.addEventListener('click', () => {
        nav.classList.toggle('active');
    });

    // Charger la page d'accueil par défaut au chargement initial ou selon l'ancre URL
    const initialPage = window.location.hash ? window.location.hash.substring(1) : 'accueil';
    loadPage(initialPage);
});
document.addEventListener('DOMContentLoaded', () => {
    // Sélectionnez les liens de navigation qui vont charger le contenu dynamiquement.
    const navLinks = document.querySelectorAll('.nav-item');
    // La zone où le contenu de chaque page sera affiché.
    const contentArea = document.getElementById('content');
    
    // Le contenu HTML pour chaque page, y compris les nouvelles sections de la page d'accueil.
    const pageContent = {
        'accueil': `
            <section class="hero">
                <div class="section-bg" style="background-image: url('./img/background-1.jpg');"></div>
                <div class="home">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="home-content">
                                    <h1>Construire un Avenir Meilleur Ensemble</h1>
                                    <p class="lead">La Fondation [Nom de la Fondation] s'engage à transformer des vies et à créer un impact durable dans nos communautés.</p>
                                    <a href="#mission" class="primary-button nav-item">Découvrir notre mission</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div id="about" class="section">
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="section-title">
                                <h2 class="title">Qui sommes-nous ?</h2>
                                <p class="sub-title">La Fondation [Nom de la Fondation] est dédiée à l'amélioration de la société à travers des initiatives ciblées dans l'éducation, la santé et le développement durable.</p>
                            </div>
                            <div class="about-content">
                                <p>Depuis notre création, nous avons soutenu des centaines de projets et impacté des milliers de vies. Notre force réside dans notre engagement indéfectible et notre capacité à mobiliser des ressources pour les causes qui comptent le plus.</p>
                                <a href="#mission" class="primary-button nav-item">En savoir plus</a>
                            </div>
                        </div>
                        <div class="col-md-offset-1 col-md-6">
                            <img src="./img/about.jpg" alt="Image de la fondation" class="img-responsive">
                        </div>
                    </div>
                </div>
            </div>

            <div id="numbers" class="section">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-6">
                            <div class="number">
                                <i class="fa fa-smile-o"></i>
                                <h3>47k</h3>
                                <span>Donateurs</span>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="number">
                                <i class="fa fa-heartbeat"></i>
                                <h3>154K</h3>
                                <span>Enfants aidés</span>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="number">
                                <i class="fa fa-money"></i>
                                <h3>785K</h3>
                                <span>Donations en $</span>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="number">
                                <i class="fa fa-handshake-o"></i>
                                <h3>357</h3>
                                <span>Volontaires</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="cta" class="section">
                <div class="section-bg" style="background-image: url(./img/background-2.jpg);" data-stellar-background-ratio="0.5"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8">
                            <div class="cta-content text-center">
                                <h1>Rejoignez notre mission !</h1>
                                <p class="lead">Votre soutien nous permet de continuer notre travail essentiel. Chaque don, chaque partenariat compte.</p>
                                <a href="#contact" class="primary-button nav-item">Faire un don ou Devenir partenaire</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `,
        'vision': `
            <section id="vision" class="section page-content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h2>Notre Vision</h2>
                            <p>Nous aspirons à un monde où l'égalité des chances et la durabilité sont au cœur de chaque communauté. Notre vision est de créer un impact durable et positif sur les générations futures.</p>
                            <p>Nous imaginons une société où chaque individu a accès aux ressources nécessaires pour s'épanouir, où l'éducation est un droit universel, la santé une priorité et l'environnement un patrimoine protégé pour tous. C'est vers cet idéal que nous orientons toutes nos actions et nos partenariats.</p>
                        </div>
                    </div>
                </div>
            </section>
        `,
        'mission': `
            <section id="mission" class="section page-content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h2>Notre Mission</h2>
                            <p>Notre mission est de financer et de soutenir des projets qui transforment la vie des individus et des communautés. Nous nous concentrons sur l'éducation, la santé et l'environnement, car nous croyons en leur pouvoir de changer le monde.</p>
                            <p>Nous identifions les besoins critiques, collaborons avec des organisations locales et internationales, et investissons dans des solutions innovantes. Notre objectif est de maximiser l'efficacité de nos interventions et d'assurer une amélioration tangible et mesurable dans la vie des personnes que nous servons.</p>
                        </div>
                    </div>
                </div>
            </section>
        `,
        'valeurs': `
            <section id="valeurs" class="section page-content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h2>Nos Valeurs</h2>
                            <ul>
                                <li><strong>Transparence:</strong> Nous agissons avec intégrité, honnêteté et clarté dans toutes nos opérations et nos rapports financiers.</li>
                                <li><strong>Empathie:</strong> Nous nous mettons à la place des communautés que nous servons, en écoutant attentivement leurs besoins et en y répondant avec compassion.</li>
                                <li><strong>Innovation:</strong> Nous cherchons constamment des approches nouvelles et créatives pour résoudre les défis complexes et maximiser notre impact.</li>
                                <li><strong>Collaboration:</strong> Nous croyons en la force du partenariat, travaillant main dans la main avec d'autres organisations, donateurs et bénéficiaires.</li>
                                <li><strong>Responsabilité:</strong> Nous nous engageons à une gestion rigoureuse de nos ressources et à la redevabilité envers nos parties prenantes.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>
        `,
        'charte': `
            <section id="charte" class="section page-content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h2>Notre Charte Éthique</h2>
                            <p>La charte de la fondation établit nos principes de conduite, nos engagements éthiques et nos directives de fonctionnement pour garantir une gouvernance responsable et efficace. Elle guide toutes nos décisions et actions, assurant que nous restons fidèles à notre mission et à nos valeurs.</p>
                            <p>Elle couvre des aspects tels que la gestion des fonds, la non-discrimination, la protection des données, et les relations avec nos partenaires et le public. Tous les membres de la fondation s'engagent à respecter cette charte.</p>
                        </div>
                    </div>
                </div>
            </section>
        `,
        'gouvernance': `
            <section id="gouvernance" class="section page-content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h2>Gouvernance de la Fondation</h2>
                            <p>Notre structure de gouvernance est composée d'un conseil d'administration et d'un comité exécutif, garantissant une gestion saine et une allocation stratégique des ressources. Chaque organe joue un rôle essentiel pour assurer la transparence, l'efficacité et l'alignement avec notre mission.</p>
                            <h3>Conseil d'Administration</h3>
                            <p>Le Conseil d'Administration supervise la stratégie générale, la gestion financière et la conformité légale de la fondation. Il est composé de membres experts issus de divers domaines.</p>
                            <h3>Comité Exécutif</h3>
                            <p>Le Comité Exécutif est responsable de la mise en œuvre des décisions du Conseil et de la gestion quotidienne des opérations de la fondation, sous la direction du Directeur Général.</p>
                        </div>
                    </div>
                </div>
            </section>
        `,
        'contact': `
            <section id="contact" class="section page-content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h2>Contactez-nous</h2>
                            <p>Vous avez une question, une proposition de partenariat ou souhaitez faire un don ? N'hésitez pas à nous contacter. Notre équipe est à votre disposition pour vous répondre dans les plus brefs délais.</p>
                            <form>
                                <label for="nom">Nom Complet:</label><br>
                                <input type="text" id="nom" name="nom" required><br><br>
                                <label for="email">Adresse Email:</label><br>
                                <input type="email" id="email" name="email" required><br><br>
                                <label for="sujet">Sujet:</label><br>
                                <input type="text" id="sujet" name="sujet"><br><br>
                                <label for="message">Votre Message:</label><br>
                                <textarea id="message" name="message" rows="6" required></textarea><br><br>
                                <button type="submit" class="primary-button">Envoyer le message</button>
                            </form>
                            <p style="margin-top: 2rem;"><strong>Email:</strong> info@votrefondation.com</p>
                            <p><strong>Téléphone:</strong> +123 456 7890</p>
                            <p><strong>Adresse:</strong> 123 Rue de la Fondation, Ville, Code Postal</p>
                        </div>
                    </div>
                </div>
            </section>
        `
    };

    // Fonction pour charger le contenu de la page
    const loadPage = (pageName) => {
        contentArea.innerHTML = pageContent[pageName] || pageContent['accueil'];
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    // Gérer la navigation
    navLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const page = link.getAttribute('href').substring(1);
            loadPage(page);
        });
    });

    // Charger la page d'accueil par défaut au chargement initial ou selon l'ancre URL
    const initialPage = window.location.hash ? window.location.hash.substring(1) : 'accueil';
    loadPage(initialPage);
});